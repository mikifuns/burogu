//lazyload
var myLazyLoad = new LazyLoad();